#!/bin/bash
python3 /home/pi/diansai/Asuoding_pink.py &