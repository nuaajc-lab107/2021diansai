#!/bin/bash
python3 /home/pi/diansai/Bsuoding_pink.py &