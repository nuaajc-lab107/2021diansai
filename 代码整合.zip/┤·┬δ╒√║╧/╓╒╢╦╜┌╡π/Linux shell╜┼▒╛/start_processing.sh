#!/bin/bash
sleep 30
sudo sh /home/pi/diansai/A.sh && sudo sh /home/pi/diansai/B.sh && sudo sh /home/pi/diansai/gpio_service.sh
