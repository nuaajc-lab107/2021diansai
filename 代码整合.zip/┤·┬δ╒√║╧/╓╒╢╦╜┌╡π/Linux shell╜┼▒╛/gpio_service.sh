#!/bin/bash
sudo python3 /home/pi/diansai/gpio.py